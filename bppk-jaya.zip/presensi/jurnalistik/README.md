# presensi karista coy
